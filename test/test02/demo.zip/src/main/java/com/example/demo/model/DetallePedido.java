package com.example.demo.model;

import javax.persistence.*;

@Entity
public class DetallePedido {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    @ManyToOne
    private Producto producto;
    private int cantidad;
    @ManyToOne
    private Carrito carrito;
}