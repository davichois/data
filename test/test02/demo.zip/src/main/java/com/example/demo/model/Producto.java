package com.example.demo.model;

import javax.persistence.*;
import java.util.Set;

@Entity
public class Producto {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    private String nombre;
    private double precio;
    @ManyToOne
    private Categoria categoria;
    @ManyToMany(mappedBy = 'productos')
    private Set<Etiqueta> etiquetas;
}