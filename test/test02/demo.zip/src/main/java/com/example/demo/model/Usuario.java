package com.example.demo.model;

import javax.persistence.*;

@Entity
public class Usuario {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    private String nombre;
    private String email;
    @OneToOne(mappedBy = 'usuario')
    private Carrito carrito;
    @OneToOne(mappedBy = 'usuario')
    private Sesion sesion;
}