package com.example.demo.model;

import javax.persistence.*;
import java.util.Set;

@Entity
public class Categoria {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    private String descripcion;
    @OneToMany(mappedBy = 'categoria')
    private Set<Producto> productos;
}