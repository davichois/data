package com.example.demo.model;

import javax.persistence.*;
import java.util.Set;

@Entity
public class Etiqueta {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    private String nombre;
    @ManyToMany
    @JoinTable(name = 'producto_etiqueta',
              joinColumns = @JoinColumn(name = 'etiqueta_id'),
              inverseJoinColumns = @JoinColumn(name = 'producto_id'))
    private Set<Producto> productos;
}