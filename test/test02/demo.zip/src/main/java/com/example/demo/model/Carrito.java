package com.example.demo.model;

import javax.persistence.*;
import java.util.List;

@Entity
public class Carrito {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    @OneToMany(mappedBy = 'carrito')
    private List<DetallePedido> detalles;
    @OneToOne
    private Usuario usuario;
}