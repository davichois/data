package com.example.demo.model;

import javax.persistence.*;

@Entity
public class Sesion {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    private String token;
    @OneToOne
    private Usuario usuario;
}