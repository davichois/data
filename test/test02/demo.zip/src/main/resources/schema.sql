CREATE TABLE IF NOT EXISTS Categoria (
    id BIGINT AUTO_INCREMENT PRIMARY KEY,
    descripcion VARCHAR(255) NOT NULL
);

CREATE TABLE IF NOT EXISTS Producto (
    id BIGINT AUTO_INCREMENT PRIMARY KEY,
    nombre VARCHAR(255) NOT NULL,
    precio DOUBLE NOT NULL,
    categoria_id BIGINT,
    FOREIGN KEY (categoria_id) REFERENCES Categoria(id)
);

CREATE TABLE IF NOT EXISTS Etiqueta (
    id BIGINT AUTO_INCREMENT PRIMARY KEY,
    nombre VARCHAR(255) NOT NULL
);

CREATE TABLE IF NOT EXISTS Producto_Etiqueta (
    producto_id BIGINT,
    etiqueta_id BIGINT,
    PRIMARY KEY (producto_id, etiqueta_id),
    FOREIGN KEY (producto_id) REFERENCES Producto(id),
    FOREIGN KEY (etiqueta_id) REFERENCES Etiqueta(id)
);

CREATE TABLE IF NOT EXISTS Usuario (
    id BIGINT AUTO_INCREMENT PRIMARY KEY,
    nombre VARCHAR(255) NOT NULL,
    email VARCHAR(255) NOT NULL UNIQUE
);

CREATE TABLE IF NOT EXISTS Sesion (
    id BIGINT AUTO_INCREMENT PRIMARY KEY,
    token VARCHAR(255) NOT NULL UNIQUE,
    usuario_id BIGINT,
    FOREIGN KEY (usuario_id) REFERENCES Usuario(id)
);

CREATE TABLE IF NOT EXISTS Carrito (
    id BIGINT AUTO_INCREMENT PRIMARY KEY,
    usuario_id BIGINT UNIQUE,
    FOREIGN KEY (usuario_id) REFERENCES Usuario(id)
);

CREATE TABLE IF NOT EXISTS DetallePedido (
    id BIGINT AUTO_INCREMENT PRIMARY KEY,
    producto_id BIGINT,
    cantidad INT NOT NULL,
    carrito_id BIGINT,
    FOREIGN KEY (producto_id) REFERENCES Producto(id),
    FOREIGN KEY (carrito_id) REFERENCES Carrito(id)
);