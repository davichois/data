CREATE TABLE IF NOT EXISTS `User` (
    `id` BIGINT AUTO_INCREMENT PRIMARY KEY,
    `username` VARCHAR(255) NOT NULL,
    `password` VARCHAR(255) NOT NULL
);

CREATE TABLE IF NOT EXISTS `Product` (
    `id` BIGINT AUTO_INCREMENT PRIMARY KEY,
    `name` VARCHAR(255) NOT NULL,
    `price` DOUBLE NOT NULL
);

CREATE TABLE IF NOT EXISTS `Review` (
    `id` BIGINT AUTO_INCREMENT PRIMARY KEY,
    `content` TEXT,
    `product_id` BIGINT,
    FOREIGN KEY (`product_id`) REFERENCES `Product`(`id`)
);

CREATE TABLE IF NOT EXISTS `Coupon` (
    `id` BIGINT AUTO_INCREMENT PRIMARY KEY,
    `code` VARCHAR(255) NOT NULL,
    `discount` DOUBLE NOT NULL
);

CREATE TABLE IF NOT EXISTS `CartItem` (
    `id` BIGINT AUTO_INCREMENT PRIMARY KEY,
    `user_id` BIGINT,
    `product_id` BIGINT,
    `quantity` INT,
    FOREIGN KEY (`user_id`) REFERENCES `User`(`id`),
    FOREIGN KEY (`product_id`) REFERENCES `Product`(`id`)
);